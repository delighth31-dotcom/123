GSMG image variant audit — source images from delighth31-dotcom/123

FILES
- air-dark.png, air-light.png, shot-light.png, shot-dark.png
- All four are 1050×1050 px = 14×14 macro cells, each 75×75 px. The central motif is on a 15×15 microcell grid.

VERIFIED GRID FACTS
- air-light and shot-light each contain exactly 12 blue, 8 pale-yellow, and 4 orange macro cells.
- air-light has exact quarter-turn (90°/180°/270°) rotational symmetry; simple horizontal/vertical reflections are not exact.
- shot-light has exact horizontal, vertical, and 180° symmetry; diagonal/quarter-turn symmetry is not exact.
- air-dark retains a 36-cell white central mask plus four orange macro cells.
- shot-dark retains a 24-cell central white mask plus four white 75×75 flank cells and four orange macro cells.
- The two central masks overlap in 20 microcells; air-only 16; shot-only 4; union 40. The central masks do not directly equal the previously extracted 37-cell rabbit mask under simple D4 transformations and small shifts.

AIR/SHOT DELTA
- Encode K/B=1 and W/Y/O=0. The light-image 14×14 grids differ in exactly 40 cells.
- The 40-cell XOR mask is exactly symmetric across the main diagonal, has no diagonal cells, and forms 20 transposed pairs.
- The source Genesis matrix values sampled at those 40 positions contain 19 ones and 21 zeros; their complement has 21 ones and 19 zeros, the same counts as the known 40-bit enter block.
- However, row-major, column-major, serpentine, and canonical spiral reads of those 40 source bits did NOT reproduce enter exactly. Treat the count equality as a lead, not a decode.

MATRIX FIT (EXPLORATORY)
- Among tests comparing the black/white backgrounds to Boolean functions of orientations of the original Genesis matrix, NOR(M, rot180(M)) was the best simple fit at 140/172 uncolored cells (81.4%) for each light image. It is not exact: 32 background cells disagree in each variant. The two 32-cell residual masks overlap in 30 cells after transpose. This is a candidate relationship, not proof of the construction rule.
- The 40 delta coordinates are not simply the original blue/yellow coordinate set under a D4 transformation.

Coordinate convention in the CSV: row/column labels are 1-based; internal computation used 0-based positions.
